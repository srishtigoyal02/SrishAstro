package com.example.srishastro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class ForgotActivity : AppCompatActivity() {
    private lateinit var btnNext:Button
    private lateinit var etMobileNumber:EditText
    private lateinit var etEmail:EditText
    private var validMobileNumber="9877712024"
    private var validEmail="srishtigoyal987@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_forgot)

        title="Forgot Password"

        etEmail=findViewById(R.id.etEmail)
        etMobileNumber=findViewById(R.id.etMobileNumber)
        btnNext=findViewById(R.id.btnNext)

        btnNext.setOnClickListener {
            val mobileNumber=etMobileNumber.text.toString()
            val email=etEmail.text.toString()

            if (mobileNumber==validMobileNumber && email==validEmail){
            startActivity(Intent(this@ForgotActivity,Login2Activity::class.java))
            }
            else{
            Toast.makeText(this@ForgotActivity,"Incorrect Credentials",Toast.LENGTH_LONG).show()
        }
        }
    }

    override fun onPause() {
        super.onPause()
        finish()
    }

}