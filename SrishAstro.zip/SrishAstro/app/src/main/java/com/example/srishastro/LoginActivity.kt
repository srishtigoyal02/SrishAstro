package com.example.srishastro

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import android.widget.Button as Button1

class LoginActivity : AppCompatActivity() {

    private lateinit var etMobileNumber:EditText
    private lateinit var etPassword:EditText
    private lateinit var btnLogIn: Button1
    private lateinit var btnForgotPassword: Button1
    private lateinit var btnRegister: Button1
    private var validMobileNumber="1234567895"
    private var validPassword="srishti"
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences = getSharedPreferences(
            getString(R.string.preference_file_name),
            MODE_PRIVATE
        )
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        setContentView(R.layout.activity_login)

        if (isLoggedIn) {
            startActivity(Intent(this@LoginActivity, Login2Activity::class.java))
            finish()
        }
        title="Log In"

        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)
        btnForgotPassword = findViewById(R.id.btnForgotPassword)
        btnLogIn = findViewById(R.id.btnLogIn)
        btnRegister = findViewById(R.id.btnRegister)

        btnForgotPassword.setOnClickListener {
            startActivity(Intent(this@LoginActivity,ForgotActivity::class.java))
        }

        btnRegister.setOnClickListener {
            startActivity(Intent(this@LoginActivity,RegisterActivity::class.java))
        }

        btnLogIn.setOnClickListener{
            val mobileNumber = etMobileNumber.text.toString()
            val password = etPassword.text.toString()
            if (mobileNumber == validMobileNumber && password == validPassword) {
                startActivity(Intent(this@LoginActivity, Login2Activity::class.java))
                savePreferences()
            }
            else {
                Toast.makeText(
                    this@LoginActivity,
                    "Re-enter the valid credentials or Sign Up instead",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
    override fun onPause() {
        super.onPause()
        finish()
    }
    private fun savePreferences()
    {
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
    }
}