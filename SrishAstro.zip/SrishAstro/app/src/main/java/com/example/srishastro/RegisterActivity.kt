package com.example.srishastro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class RegisterActivity : AppCompatActivity() {
    lateinit var etName:EditText
    lateinit var etEmail:EditText
    lateinit var etMobileNumberRegister:EditText
    private lateinit var etPasswordRegister:EditText
    lateinit var btnSignUp:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        title="Create a new account"
        etName=findViewById(R.id.etName)
        etEmail=findViewById(R.id.etEmail)
        etMobileNumberRegister=findViewById(R.id.etMobileNumberRegister)
        etPasswordRegister=findViewById(R.id.etPasswordRegister)
        btnSignUp=findViewById(R.id.btnSignUp)

        btnSignUp.setOnClickListener {
            val name=etName.text.toString()
            val email =etEmail.text.toString()
            val mobileNumber=etMobileNumberRegister.text.toString()
            val password=etPasswordRegister.text.toString()
            val intent=Intent(this@RegisterActivity,Login2Activity::class.java)
            intent.putExtra("Details", arrayListOf(name,email,mobileNumber,password))
            startActivity(intent)
        }
    }
}